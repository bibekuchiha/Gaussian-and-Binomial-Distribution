from setuptools import setup

setup(name='Bibekdistribution',
      version='0.1',
      description='Gaussian and Binary distributions',
      packages=['Bibekdistribution'],
      author= 'Bibek Shah Shankhar',
      author_email='shahshankharbibek@gmail.com',
      zip_safe=False)